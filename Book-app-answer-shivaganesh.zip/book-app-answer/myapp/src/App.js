// src/App.js
import React from 'react';
import BookManager from './components/BookManager';

function App() {
  return (
    <div className="App" >
      <BookManager />
    </div>
  );
}

export default App;


// src/BookManagement.js
import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

export default function BookManager() {
  const [bookData, setBookData] = useState({
    name: "",
    author: "",
    publication: "",
    price: "",
  });

  const [bookList, setBookList] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookData({ ...bookData, [name]: value });
  };

  const addBook = () => {
    if (
      bookData.name.trim() === "" ||
      bookData.author.trim() === "" ||
      bookData.publication.trim() === "" ||
      bookData.price.trim() === ""
    ) {
      alert("All fields are required");
      return;
    }

    setBookList([...bookList, bookData]);
    setBookData({ name: "", author: "", publication: "", price: "" });
  };

  return (
    <div className="container">
      <div className="row justify-content-md-center">
        <div>
          <h1>Book Manager</h1>
          <p>
            Fill the details to enter the book information in the Book List
            table below:
          </p>
          <div className="row">
            <div className="col-md-5">
              <div className="form-group">
                <label>Name of the Book:</label>
                <input
                  type="text"
                  name="name"
                  value={bookData.name}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="form-group">
                <label>Author:</label>
                <input
                  type="text"
                  name="author"
                  value={bookData.author}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="form-group">
                <label>Publication:</label>
                <input
                  type="text"
                  name="publication"
                  value={bookData.publication}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="form-group">
                <label>Price:</label>
                <input
                  type="text"
                  name="price"
                  value={bookData.price}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
            </div>
          </div>
          <button onClick={addBook} className="btn btn-primary">
            Add Book
          </button>
        </div>

        <div className="col-md-12">
          <h2>Book List</h2>
          <table className="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Name</th>
                <th>Author</th>
                <th>Publication</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              {bookList.map((book, index) => (
                <tr key={index}>
                  <td>{book.name}</td>
                  <td>{book.author}</td>
                  <td>{book.publication}</td>
                  <td>{book.price}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
